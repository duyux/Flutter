import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

class Day0Page extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CupertinoNavigationBar(
        middle: Text('TO BE UPDATED'),
      ),
      body: Container(
        child: Center(
          child: Text('TO BE UPDATED'),
        )
      ),
    );
  }
}