import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
class BookPage extends StatefulWidget {
  @override
  BookPageState createState() => new BookPageState();
}

class BookPageState extends State<BookPage> {
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return new Center(child: new Text('小册'),);
  }
}