# 山寨掘金第一天

![](screenshots/day1/complete.gif)

